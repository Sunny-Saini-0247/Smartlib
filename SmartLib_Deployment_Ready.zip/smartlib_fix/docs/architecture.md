# SmartLib Architecture

Webcam -> OpenCV -> YuNet Face Detection -> SFace Embedding -> Similarity Matching -> User Database -> ENTRY/EXIT -> Attendance Database -> Dashboard.

The gate uses a cooldown to reduce duplicate events while the same person remains in view.

Future physical security layer:
RFID/barcode reader -> Library Item Database -> authorization check -> buzzer/siren/alert.
