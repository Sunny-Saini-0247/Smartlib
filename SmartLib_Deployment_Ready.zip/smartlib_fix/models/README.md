Run download_models.py to download the YuNet and SFace ONNX models.
